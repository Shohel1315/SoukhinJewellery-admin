# Run this script in PowerShell with Flutter & Android SDK set up.
# It builds locally; DOES NOT change anything on soukhinjewellery.com.
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

function RunStep([string]$exe, [string[]]$arguments) {
  Write-Host "`n> $exe $($arguments -join ' ')" -ForegroundColor Cyan
  & $exe @arguments
  if ($LASTEXITCODE -ne 0) { throw "$exe exited with code $LASTEXITCODE" }
}

if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
  throw 'Flutter command not found. Install Flutter SDK and add Flutter/bin to PATH.'
}
RunStep 'flutter' @('doctor')
RunStep 'flutter' @('create', '--project-name', 'soukhin_admin', '--platforms=android', '--org', 'com.soukhinjewellery', '.')

if (Get-Command py -ErrorAction SilentlyContinue) {
  RunStep 'py' @('tools/prepare_android.py')
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
  RunStep 'python' @('tools/prepare_android.py')
} else {
  throw 'Python 3 is needed to apply Android manifest + minSdk configuration.'
}

RunStep 'flutter' @('pub', 'get')
RunStep 'flutter' @('analyze')
RunStep 'flutter' @('test')
RunStep 'flutter' @('build', 'apk', '--release')
Write-Host "`nAPK output: $PSScriptRoot\build\app\outputs\flutter-apk\app-release.apk" -ForegroundColor Green
Write-Host 'This is a local build. Configure production signing before broad distribution.'
