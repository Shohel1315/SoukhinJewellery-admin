import 'package:flutter/material.dart';

import '../data/admin_links.dart';
import '../widgets/admin_shortcut_card.dart';

/// Native app shell and navigation. Screens open the existing live Laravel
/// admin in authenticated WebViews until vetted REST APIs are implemented.
class NativeHomeScreen extends StatelessWidget {
  const NativeHomeScreen({super.key, required this.onOpen,
    required this.onOpenFullAdmin, required this.onSettings});

  final ValueChanged<AdminLink> onOpen;
  final VoidCallback onOpenFullAdmin;
  final VoidCallback onSettings;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Soukhin Admin',
          style: TextStyle(fontWeight: FontWeight.w700)),
        leading: const Icon(Icons.diamond_outlined),
        actions: [
          IconButton(tooltip: 'Default mode settings',
            onPressed: onSettings, icon: const Icon(Icons.settings_outlined)),
        ],
      ),
      body: SafeArea(child: LayoutBuilder(builder: (context, size) {
        final cols = size.maxWidth >= 700 ? 4 : (size.maxWidth >= 490 ? 3 : 2);
        return ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 24), children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [colors.primary,
                colors.primary.withValues(alpha: .78)]),
              borderRadius: BorderRadius.circular(20),
            ),
            padding: const EdgeInsets.all(20),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Icon(Icons.diamond, color: Colors.white, size: 28),
              const SizedBox(height: 10),
              const Text('Soukhin Jewellery',
                style: TextStyle(color: Colors.white, fontSize: 23,
                  fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              const Text('Your existing admin, accessible on mobile',
                style: TextStyle(color: Colors.white70)),
              const SizedBox(height: 16),
              FilledButton.tonalIcon(
                onPressed: onOpenFullAdmin,
                icon: const Icon(Icons.open_in_browser_outlined),
                label: const Text('Open full website Admin'),
              ),
            ]),
          ),
          const SizedBox(height: 18),
          Text('Quick access', style: Theme.of(context).textTheme.titleLarge
            ?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Text('Every action runs through the existing Laravel admin.',
            style: TextStyle(color: colors.onSurfaceVariant, fontSize: 13)),
          const SizedBox(height: 14),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: adminLinks.length,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: cols,
              crossAxisSpacing: 10, mainAxisSpacing: 10,
              childAspectRatio: cols >= 3 ? 1.22 : 1.05,
            ),
            itemBuilder: (context, index) => AdminShortcutCard(
              link: adminLinks[index], onPressed: () => onOpen(adminLinks[index])),
          ),
          const SizedBox(height: 15),
          Text('Manual Purchase safety: This menu never fires a Meta event. '
            'Only your existing order-page Admin button can request one.',
            style: TextStyle(fontSize: 12, color: colors.onSurfaceVariant)),
        ]);
      })),
    );
  }
}
