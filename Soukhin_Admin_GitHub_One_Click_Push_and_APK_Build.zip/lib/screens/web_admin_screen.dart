// ignore_for_file: deprecated_member_use

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../core/app_config.dart';

class WebAdminScreen extends StatefulWidget {
  const WebAdminScreen({super.key, required this.initialUri,
    this.onSettings, this.rootMode = false, this.title = 'Website Admin'});

  final Uri initialUri;
  final VoidCallback? onSettings;
  final bool rootMode;
  final String title;

  @override
  State<WebAdminScreen> createState() => _WebAdminScreenState();
}

class _WebAdminScreenState extends State<WebAdminScreen> {
  late final WebViewController controller;
  int progress = 0;
  bool pageLoading = true;
  String? mainFrameError;

  @override
  void initState() {
    super.initState();
    if (!AppConfig.isTrustedWebUrl(widget.initialUri)) {
      throw ArgumentError.value(widget.initialUri, 'initialUri');
    }
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..setNavigationDelegate(NavigationDelegate(
        onProgress: (value) {
          if (mounted) setState(() => progress = value);
        },
        onPageStarted: (url) {
          if (mounted) setState(() {
            pageLoading = true;
            mainFrameError = null;
          });
        },
        onPageFinished: (url) {
          if (mounted) setState(() => pageLoading = false);
        },
        onWebResourceError: (error) {
          if (error.isForMainFrame == true && mounted) {
            setState(() {
              mainFrameError = error.description;
              pageLoading = false;
            });
          }
        },
        onNavigationRequest: _onNavigation,
      ))
      ..loadRequest(widget.initialUri);
  }

  NavigationDecision _onNavigation(NavigationRequest navigation) {
    final uri = Uri.tryParse(navigation.url);
    if (uri == null) return NavigationDecision.prevent;
    if (AppConfig.isTrustedWebUrl(uri)) return NavigationDecision.navigate;
    if (uri.scheme == 'about' && uri.toString() == 'about:blank') {
      return NavigationDecision.navigate;
    }
    // External shops, payment pages, WhatsApp/calls, and other domains
    // are never given the authenticated website WebView context.
    if (const {'https', 'http', 'tel', 'mailto', 'sms', 'whatsapp'}
        .contains(uri.scheme)) {
      unawaited(_launchExternal(uri));
    }
    return NavigationDecision.prevent;
  }

  Future<void> _launchExternal(Uri uri) async {
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Cannot open this link on this phone.')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('External app unavailable.')),
        );
      }
    }
  }

  Future<bool> _onWillPop() async {
    if (await controller.canGoBack()) {
      await controller.goBack();
      return false;
    }
    return true;
  }

  Future<void> _openCurrentInBrowser() async {
    final url = await controller.currentUrl();
    if (url != null) await _launchExternal(Uri.parse(url));
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.title, maxLines: 1,
            overflow: TextOverflow.ellipsis),
          actions: [
            IconButton(tooltip: 'Admin home',
              icon: const Icon(Icons.home_outlined),
              onPressed: () => controller.loadRequest(
                AppConfig.adminUri('/admin/dashboard'))),
            IconButton(tooltip: 'Refresh',
              icon: const Icon(Icons.refresh),
              onPressed: controller.reload),
            IconButton(tooltip: 'Open in browser',
              icon: const Icon(Icons.open_in_browser),
              onPressed: _openCurrentInBrowser),
            if (widget.onSettings != null)
              IconButton(tooltip: 'Default mode settings',
                icon: const Icon(Icons.settings_outlined),
                onPressed: widget.onSettings),
          ],
        ),
        body: SafeArea(child: Stack(children: [
          Positioned.fill(child: WebViewWidget(controller: controller)),
          if (pageLoading)
            Align(alignment: Alignment.topCenter,
              child: LinearProgressIndicator(value: progress > 0 && progress < 100
                ? progress / 100 : null, minHeight: 3)),
          if (mainFrameError != null)
            Positioned.fill(child: ColoredBox(color: Theme.of(context).colorScheme.surface,
              child: Center(child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.wifi_off_rounded, size: 48),
                  const SizedBox(height: 12),
                  const Text('Could not load the Admin page'),
                  const SizedBox(height: 6),
                  Text(mainFrameError!, textAlign: TextAlign.center),
                  const SizedBox(height: 16),
                  FilledButton(onPressed: () => controller.reload(),
                    child: const Text('Retry')),
                ]),
              )))),
        ])),
      ),
    );
  }
}
