import 'package:flutter/material.dart';

import '../core/admin_mode.dart';
import '../core/app_settings.dart';

class ModeSettingsScreen extends StatefulWidget {
  const ModeSettingsScreen({super.key, required this.settings});
  final AppSettings settings;

  @override
  State<ModeSettingsScreen> createState() => _ModeSettingsScreenState();
}

class _ModeSettingsScreenState extends State<ModeSettingsScreen> {
  late AdminMode selection;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    selection = widget.settings.mode;
  }

  Future<void> _save() async {
    if (saving) return;
    setState(() => saving = true);
    try {
      await widget.settings.saveDefaultMode(selection);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${selection.label} saved on this device')),
      );
      Navigator.of(context).pop();
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not save. Please try again.')),
      );
      setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Admin app settings')),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
        Text('Choose your default Admin mode',
          style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 9),
        const Text('The setting is saved on this phone only. Other Admin devices '
          'keep their own selected mode.'),
        const SizedBox(height: 22),
        RadioGroup<AdminMode>(groupValue: selection,
          onChanged: (v) { if (v != null) setState(() => selection = v); },
          child: Column(children: [
            Card(child: RadioListTile<AdminMode>(
              value: AdminMode.native,
              title: const Text('Native dashboard'),
              subtitle: const Text('Flutter shortcut UI with live website pages'),
            )),
            Card(child: RadioListTile<AdminMode>(
              value: AdminMode.webview,
              title: const Text('Full WebView Admin'),
              subtitle: const Text('Opens the complete Laravel admin dashboard'),
            )),
          ]),
        ),
        const SizedBox(height: 24),
        FilledButton.icon(
          onPressed: saving ? null : _save,
          icon: saving
              ? const SizedBox(width: 16, height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.check_circle_outline),
          label: const Text('Set as default on this phone'),
        ),
        const SizedBox(height: 16),
        Text('Website feature updates appear immediately in the WebView. '
          'New Flutter-only screens still require an app build.',
          style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
      ])),
    );
  }
}
