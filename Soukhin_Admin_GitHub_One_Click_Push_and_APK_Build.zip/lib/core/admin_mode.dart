enum AdminMode {
  native,
  webview;

  static AdminMode fromStorage(String? stored) =>
      stored == 'webview' ? AdminMode.webview : AdminMode.native;

  String get label => this == AdminMode.native
      ? 'Native dashboard'
      : 'Full website admin (WebView)';
}
