import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'admin_mode.dart';

/// Stores only non-sensitive display preference on each device.
/// Authentication remains with the existing Laravel session in WebView.
class AppSettings extends ChangeNotifier {
  AppSettings._(this._storage, this._mode);

  static const _modeKey = 'soukhin.admin.default_mode.v1';

  final SharedPreferencesAsync _storage;
  AdminMode _mode;

  AdminMode get mode => _mode;

  static Future<AppSettings> load() async {
    final storage = SharedPreferencesAsync();
    final stored = await storage.getString(_modeKey);
    return AppSettings._(storage, AdminMode.fromStorage(stored));
  }

  Future<void> saveDefaultMode(AdminMode selected) async {
    // Persist first; don't claim that the setting is saved if the write fails.
    await _storage.setString(_modeKey, selected.name);
    _mode = selected;
    notifyListeners();
  }
}
