class AppConfig {
  AppConfig._();

  static final Uri siteOrigin = Uri.parse('https://soukhinjewellery.com/');

  /// Only main-frame navigation within official storefront hosts stays
  /// in the authenticated embedded WebView. External links use Android apps.
  static const allowedHosts = <String>{
    'soukhinjewellery.com',
    'www.soukhinjewellery.com',
  };

  static Uri adminUri(String path) {
    if (!path.startsWith('/admin/')) {
      throw ArgumentError.value(path, 'path', 'Must be an admin path');
    }
    return siteOrigin.resolve(path);
  }

  static bool isTrustedWebUrl(Uri uri) =>
      uri.scheme == 'https' && allowedHosts.contains(uri.host.toLowerCase());
}
