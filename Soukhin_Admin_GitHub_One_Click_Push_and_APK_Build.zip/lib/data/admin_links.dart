import 'package:flutter/material.dart';

/// Verified against web(20261027-045248).php and
/// soukhin_mobile_admin_responsive_patch_v1 master.blade.php.
/// These are navigation URLs only; NO events and NO order actions happen here.
class AdminLink {
  const AdminLink({required this.title, required this.subtitle,
    required this.path, required this.icon});

  final String title;
  final String subtitle;
  final String path;
  final IconData icon;
}

const adminLinks = <AdminLink>[
  AdminLink(title: 'Dashboard', subtitle: 'Live website overview',
    path: '/admin/dashboard', icon: Icons.dashboard_outlined),
  AdminLink(title: 'All Orders', subtitle: 'Manage and process orders',
    path: '/admin/order/all', icon: Icons.receipt_long_outlined),
  AdminLink(title: 'Pending Orders', subtitle: 'Waiting for processing',
    path: '/admin/order/pending', icon: Icons.pending_actions_outlined),
  AdminLink(title: 'Products', subtitle: 'Manage price, image and stock',
    path: '/admin/products/manage', icon: Icons.diamond_outlined),
  AdminLink(title: 'POS', subtitle: 'Point of sale',
    path: '/admin/pos', icon: Icons.point_of_sale_outlined),
  AdminLink(title: 'Customers', subtitle: 'Customer management',
    path: '/admin/customer/manage', icon: Icons.people_outline),
  AdminLink(title: 'Incomplete Checkouts', subtitle: 'Recover checkout activity',
    path: '/admin/incomplete-checkouts', icon: Icons.remove_shopping_cart_outlined),
  AdminLink(title: 'Visual Landing Pages', subtitle: 'Current landing builder',
    path: '/admin/landing-visual-pages', icon: Icons.web_outlined),
  AdminLink(title: 'Pixel Management', subtitle: 'Manage pixels and settings',
    path: '/admin/pixels/manage', icon: Icons.ads_click_outlined),
  AdminLink(title: 'Event Fire Settings', subtitle: 'Manual purchase configuration',
    path: '/admin/event-fire/quick-settings', icon: Icons.touch_app_outlined),
  AdminLink(title: 'Sales Reports', subtitle: 'Order reporting',
    path: '/admin/order-report', icon: Icons.bar_chart_outlined),
  AdminLink(title: 'Stock Reports', subtitle: 'Inventory reporting',
    path: '/admin/stock-report', icon: Icons.inventory_2_outlined),
  AdminLink(title: 'General Settings', subtitle: 'Existing website settings',
    path: '/admin/settings/manage', icon: Icons.tune_outlined),
];
