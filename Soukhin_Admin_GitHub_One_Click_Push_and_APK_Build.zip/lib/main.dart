import 'package:flutter/material.dart';

import 'core/admin_mode.dart';
import 'core/app_config.dart';
import 'core/app_settings.dart';
import 'data/admin_links.dart';
import 'screens/mode_settings_screen.dart';
import 'screens/native_home_screen.dart';
import 'screens/web_admin_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final settings = await AppSettings.load();
  runApp(SoukhinAdminApp(settings: settings));
}

class SoukhinAdminApp extends StatelessWidget {
  const SoukhinAdminApp({super.key, required this.settings});
  final AppSettings settings;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Soukhin Jewellery Admin',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xffac346a)),
        scaffoldBackgroundColor: const Color(0xfffcf8fa),
        appBarTheme: const AppBarTheme(
          centerTitle: false,
          backgroundColor: Color(0xfffcf8fa),
        ),
      ),
      home: AppHome(settings: settings),
    );
  }
}

class AppHome extends StatelessWidget {
  const AppHome({super.key, required this.settings});
  final AppSettings settings;

  void _openSettings(BuildContext context) {
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => ModeSettingsScreen(settings: settings),
    ));
  }

  void _openLink(BuildContext context, AdminLink link) {
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => WebAdminScreen(
        initialUri: AppConfig.adminUri(link.path), title: link.title),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(animation: settings, builder: (context, _) {
      if (settings.mode == AdminMode.webview) {
        return WebAdminScreen(
          key: const ValueKey('web-admin-root'),
          rootMode: true,
          initialUri: AppConfig.adminUri('/admin/dashboard'),
          title: 'Soukhin Admin',
          onSettings: () => _openSettings(context),
        );
      }
      return NativeHomeScreen(
        key: const ValueKey('native-root'),
        onOpen: (link) => _openLink(context, link),
        onOpenFullAdmin: () => _openLink(context, adminLinks.first),
        onSettings: () => _openSettings(context),
      );
    });
  }
}
