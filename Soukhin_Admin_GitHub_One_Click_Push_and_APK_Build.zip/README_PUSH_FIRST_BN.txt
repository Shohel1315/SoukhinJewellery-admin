Soukhin Jewellery Android App - GitHub Push (Windows)

1) This repository is PUBLIC. If you want it private, change Github repository visibility under Settings before uploading.
2) Download and extract the ZIP on Windows. Check that the extracted root has lib/, .github/, pubspec.yaml and PUSH_TO_GITHUB_WINDOWS.ps1.
3) Install Git for Windows if necessary: https://git-scm.com/download/win
4) Open PowerShell inside the extracted folder and run:  powershell -ExecutionPolicy Bypass -File .\PUSH_TO_GITHUB_WINDOWS.ps1
5) Sign in to GitHub in your browser when prompted. Do NOT send your password or token to anyone.
6) Once pushed, open https://github.com/Shohel1315/SoukhinJewellery-admin/actions
7) Select Build Soukhin Admin Android APK. After it completes successfully, download artifact Soukhin-Admin-Android-APK and extract app-debug.apk.

The APK has NOT yet been compiled and its real-device behavior is unverified.
This first version has full Laravel WebView + Flutter native shortcuts (which open web pages), not complete REST-API-native management.
Website, checkout, payment, POS, and Meta events remain unchanged.
