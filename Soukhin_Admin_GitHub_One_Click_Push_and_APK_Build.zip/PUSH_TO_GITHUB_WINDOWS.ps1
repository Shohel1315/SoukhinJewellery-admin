# Soukhin Jewellery Android app: push source to GitHub and trigger Actions APK build.
# Extract the ZIP first, then run this script inside the extracted folder.
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$repoUrl = 'https://github.com/Shohel1315/SoukhinJewellery-admin.git'

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    throw 'Git is not installed. Install Git for Windows from https://git-scm.com/download/win first.'
}
if (-not (Test-Path '.github/workflows/android-apk.yml')) {
    throw 'Missing .github workflow. Extract the entire ZIP, including hidden .github folder.'
}
if (-not (Test-Path 'lib/main.dart')) {
    throw 'Missing lib/main.dart. Run this script from the extracted source folder.'
}
if (-not (Test-Path '.git')) {
    git init -b main
    if ($LASTEXITCODE -ne 0) { throw 'git init failed' }
}
git branch -M main
if ($LASTEXITCODE -ne 0) { throw 'Cannot select main branch' }

$existing = git remote get-url origin 2>$null
if ($LASTEXITCODE -eq 0) {
    if ($existing.Trim() -ne $repoUrl) {
        throw "Existing origin differs from expected repository: $existing"
    }
} else {
    git remote add origin $repoUrl
    if ($LASTEXITCODE -ne 0) { throw 'Adding remote origin failed' }
}

git add --all
if ($LASTEXITCODE -ne 0) { throw 'git add failed' }
git diff --cached --quiet
$hasChanges = ($LASTEXITCODE -eq 1)
$hasHead = (git rev-parse --verify HEAD 2>$null)
if ($hasChanges -or (-not $hasHead)) {
    git commit -m 'Add Soukhin Admin Flutter app and automatic APK build'
    if ($LASTEXITCODE -ne 0) {
        throw 'Commit failed. Configure Git user.name and user.email, then rerun.'
    }
} else {
    Write-Host 'No new files to commit.' -ForegroundColor Yellow
}

Write-Host 'Uploading Flutter app to GitHub...' -ForegroundColor Cyan
git push -u origin main
if ($LASTEXITCODE -ne 0) {
    throw 'Push failed. Sign in to GitHub when prompted and verify repository permissions.'
}
Write-Host 'Push successful. APK build starts automatically in GitHub Actions.' -ForegroundColor Green
Write-Host 'Open: https://github.com/Shohel1315/SoukhinJewellery-admin/actions'
