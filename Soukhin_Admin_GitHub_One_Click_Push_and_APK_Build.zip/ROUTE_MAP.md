# Verified Laravel Admin links (snapshot: 2026-10-27)

| Feature | GET path | Evidence in previous snapshot |
|---|---|---|
| Login | `/admin/login` | `web.php` auth route |
| Dashboard | `/admin/dashboard` | `web.php` DashboardController |
| All Orders | `/admin/order/all` | `web.php` + `master.blade.php` (`slug => all`) |
| Pending Orders | `/admin/order/pending` | `master.blade.php` (`slug => pending`) |
| Products | `/admin/products/manage` | `web.php` ProductController |
| POS | `/admin/pos` | `web.php` PosController |
| Customers | `/admin/customer/manage` | `web.php` CustomerManageController |
| Incomplete Checkouts | `/admin/incomplete-checkouts` | `web.php` IncompleteCheckoutController |
| Visual Landing | `/admin/landing-visual-pages` | `web.php` LandingVisualBuilderController |
| Pixel Management | `/admin/pixels/manage` | `web.php` PixelsController |
| Event Fire Settings | `/admin/event-fire/quick-settings` | `web.php` EventFireQuickPurchaseController |
| Reports | `/admin/order-report` | `web.php` OrderController |
| Stock | `/admin/stock-report` | `web.php` OrderController |
| Settings | `/admin/settings/manage` | `web.php` GeneralSettingController |

These are *read/display navigation routes*, not permission bypasses. Existing Laravel web auth, lock and CSRF protections remain responsible for privileged actions.

## Manual Purchase Event rules

`/admin/order/{id}/meta-purchase` GET is the **existing read-only display** page; its POST endpoint sends an event. `/admin/order/{id}/quick-meta-purchase` is also a POST action. **Neither POST action is called by this Android app**, and no automatic purchase logic is added.

## Compatibility

Routes were found in a local snapshot and are not verified against an authenticated current production session. For any newly added admin modules, WebView mode exposes the site's live navigation without changing APK code.
