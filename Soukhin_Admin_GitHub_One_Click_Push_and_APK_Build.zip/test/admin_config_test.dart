import 'package:flutter_test/flutter_test.dart';
import 'package:soukhin_admin/core/admin_mode.dart';
import 'package:soukhin_admin/core/app_config.dart';
import 'package:soukhin_admin/data/admin_links.dart';

void main() {
  test('device choice falls back to native without saved preference', () {
    expect(AdminMode.fromStorage(null), AdminMode.native);
    expect(AdminMode.fromStorage('webview'), AdminMode.webview);
    expect(AdminMode.fromStorage('bad_value'), AdminMode.native);
  });

  test('admin quicklinks are scoped to the trusted website', () {
    for (final link in adminLinks) {
      final url = AppConfig.adminUri(link.path);
      expect(AppConfig.isTrustedWebUrl(url), true);
      expect(url.path.startsWith('/admin/'), true);
    }
    expect(AppConfig.isTrustedWebUrl(Uri.parse('http://soukhinjewellery.com/admin/login')), false);
    expect(AppConfig.isTrustedWebUrl(Uri.parse('https://attacker.test/admin/dashboard')), false);
    expect(() => AppConfig.adminUri('/customer/login'), throwsArgumentError);
  });

  test('manual purchase fire is never a shortcut URL', () {
    expect(adminLinks.any((l) => l.path.contains('quick-meta-purchase')), false);
    expect(adminLinks.any((l) => l.path.endsWith('/meta-purchase')), false);
  });
}
