# Soukhin Admin APK — Windows/Android SDK ছাড়াই GitHub Cloud Build

**অবস্থা:** এই ZIP-এ Flutter App Source + GitHub Actions cloud build setup আছে। APK এখানে compile করা হয়নি।

## GitHub Actions দিয়ে Android APK বানানো

১. github.com-এ নিজের অ্যাকাউন্টে একটি নতুন **Private** Repository তৈরি করুন, যেমন `soukhin-admin-app`।
২. এই ZIP-টি Extract করুন। `soukhin_admin_dual_mode_v1` ফোল্ডারের **ভেতরের সব ফাইল এবং hidden `.github` folder** Repository-র root-এ Upload/Commit করুন। (.github folder-টি বাদ দেওয়া যাবে না।)
   - GitHub web upload করার সময় nested folder যেন না হয় তা নিশ্চিত করুন।
   - বিকল্প: GitHub Desktop দিয়ে Repository Clone করে ফাইলগুলো copy ও push করুন।
৩. GitHub Repository → **Actions** → **Build Soukhin Admin Android APK** → **Run workflow** → branch `main` → **Run workflow**। Push করলেও build trigger হবে।
৪. Workflow সফল হলে একই Run-এর নিচে **Artifacts** → `Soukhin-Admin-Android-APK` ডাউনলোড করুন। ZIP-এর মধ্যে `app-debug.apk` এবং `app-release.apk` পাওয়া যাবে।
৫. প্রথম Phone Test-এর জন্য `app-debug.apk` ইনস্টল করুন। Unknown apps install permission লাগতে পারে। অচেনা কোনো APK এড়িয়ে চলুন।

## কী আছে, কী নেই

- WebView: existing HTTPS Laravel Admin Panel, web session/login, all existing web admin features subject to WebView compatibility.
- Native: Flutter shell/shortcut dashboard; action screen existing Laravel web pages-এ খোলে।
- Per-phone Native / WebView default preference saves locally.
- Web admin update reflected when reloaded; new Native features require app update.
- Facebook Meta purchase event App থেকে auto-fire করা হয় না।
- **Nowhere is a production-signed distribution keystore included.** Debug/Flutter default release builds are for testing only; production distribution requires a properly configured, owner-controlled signing key.
- **No Android phone verification has occurred.** Printing, image uploads, camera, downloads, pop-ups, OTP flows, call, WhatsApp, POS and manual Meta purchase action must be tested before trusting for real orders. Never test on real customers/purchases.
- Laravel backend, database, orders, payments, pixel code and live website are NOT changed by this package.

## GitHub Actions সম্পর্কে গুরুত্বপূর্ণ নোট

GitHub cloud build to run successfully requires access to internet/Flutter packages and GitHub Actions enabled in your repository. The first build's actual result cannot be verified here. If a build error occurs, share the **Actions error log** rather than secrets.

## Local alternative

Windows with Flutter/Android Studio set up: `BUILD_WINDOWS.ps1`.

Security: Never commit `.env`, database passwords, tokens, Google service credentials, SSH keys, keystore, or personal admin login info into a repository, even private.
