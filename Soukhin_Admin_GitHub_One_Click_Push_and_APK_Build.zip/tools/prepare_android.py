"""Safely configures a freshly flutter-created Android project for Soukhin Admin.

Run AFTER `flutter create --project-name soukhin_admin --platforms=android --org com.soukhinjewellery .`
This changes only the generated local Android wrapper, not the live Laravel site.
"""
from pathlib import Path
import re
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
manifest = root / 'android' / 'app' / 'src' / 'main' / 'AndroidManifest.xml'
if not manifest.is_file():
    raise SystemExit('AndroidManifest.xml not found. Run flutter create --project-name soukhin_admin --platforms=android --org com.soukhinjewellery . first.')

android_ns = 'http://schemas.android.com/apk/res/android'
ET.register_namespace('android', android_ns)
tree = ET.parse(manifest)
m = tree.getroot()
permission_key = f'{{{android_ns}}}name'
if not any(c.tag == 'uses-permission' and c.attrib.get(permission_key) == 'android.permission.INTERNET' for c in m):
    m.insert(0, ET.Element('uses-permission', {permission_key: 'android.permission.INTERNET'}))
application = m.find('application')
if application is None:
    raise SystemExit('Invalid Flutter Android manifest: application missing.')
application.set(f'{{{android_ns}}}label', 'Soukhin Admin')
application.set(f'{{{android_ns}}}usesCleartextTraffic', 'false')
tree.write(manifest, encoding='utf-8', xml_declaration=True)
print('Updated', manifest)

gradle_kts = root / 'android' / 'app' / 'build.gradle.kts'
gradle_old = root / 'android' / 'app' / 'build.gradle'
if gradle_kts.is_file():
    content = gradle_kts.read_text(encoding='utf-8')
    original = content
    content = re.sub(r'(?m)^\s*minSdk\s*=\s*flutter\.minSdkVersion\s*$', '        minSdk = 24', content)
    if content == original and not re.search(r'\bminSdk\s*=\s*(?:24|2[5-9]|[3-9]\d)\b', content):
        raise SystemExit('Could not set minSdk=24 in build.gradle.kts; please inspect manually.')
    gradle_kts.write_text(content, encoding='utf-8')
    print('Confirmed minSdk >=24 in', gradle_kts)
elif gradle_old.is_file():
    content = gradle_old.read_text(encoding='utf-8')
    original = content
    content = re.sub(r'(?m)^\s*minSdkVersion\s+flutter\.minSdkVersion\s*$', '        minSdkVersion 24', content)
    if content == original and not re.search(r'\bminSdk(?:Version)?\s+2[4-9]\b', content):
        raise SystemExit('Could not set minSdk=24 in build.gradle; inspect manually.')
    gradle_old.write_text(content, encoding='utf-8')
    print('Confirmed minSdk >=24 in', gradle_old)
else:
    raise SystemExit('Android Gradle build file not found.')

print('Android wrapper prepared. No live site files were touched.')
