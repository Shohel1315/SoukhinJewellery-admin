# Soukhin Jewellery — Dual Mode Android Admin App (v0.1 source)

**সাইট:** https://soukhinjewellery.com  
**প্রযুক্তি:** Flutter/Dart; Android WebView; local preference storage; existing Laravel web login/session.

## এই প্যাকেটে তৈরি করা হয়েছে

- **WebView Mode:** https://soukhinjewellery.com/admin/dashboard সরাসরি অ্যাপের মধ্যে চালানো। লগইন না থাকলে বিদ্যমান Laravel Admin Login পেজে redirect হওয়া উচিত। Admin Sidebar, বর্তমান সব Web Admin Feature এবং ভবিষ্যৎ ওয়েব UI পরিবর্তন এখান থেকেই পাওয়া যাবে।
- **Native Mode (প্রথম সংস্করণ):** সম্পূর্ণ Flutter-এর Native Home, admin shortcuts; প্রতিটি shortcut একই Existing Laravel Admin Page অ্যাপের WebView-তে চালায়। Native Order API, Native Product Editor, real-time KPI বা Push Notifications **এখনো বানানো হয়নি**। এটি নকল KPI দেখায় না।
- **Mode settings:** প্রতিটি মোবাইলে আলাদা Default Mode (`SharedPreferencesAsync`); অ্যাপ পুনরায় খুললেও নির্বাচন থাকবে। প্রথম ইনস্টলে Native Home Default।
- **সুরক্ষা:** HTTPS ও অফিসিয়াল ডোমেইনে embedded main-frame navigation; অন্য URL external app/browser-এ। অ্যাপে Admin Password/DB/Meta API Token hardcode করা নেই।
- **Manual Purchase Fire:** অ্যাপ কোনো Purchase POST/GET Event request নিজে করে না; কেবল বিদ্যমান Web Admin-এর বাটন কাজ করবে।
- **Current site unaffected:** কোনো Live PHP, Route, DB বা Server File পরিবর্তন করা হয়নি।

## গুরুত্বপূর্ণ সীমা

- এটি **Flutter Source Project**, আগে থেকে কম্পাইল করা APK নয়। এই পরিবেশে Flutter SDK/Android Build Toolchain নেই; এখানে compile/device-login test করা যায়নি।
- Admin Pages-এর সাধারণ HTML/CSS/JS WebView-তে দেখাবে, কিন্তু File Input, Print, PDF Download, Device Camera, Pop-up ও Third-party Payment/WhatsApp redirect **বাস্তব Android ফোনে আলাদা পরীক্ষা করতে হবে**। প্রতিটি external URL ফোনের browser বা corresponding app খুলবে।
- Existing Site-এর Live Code 27 Oct 2026-এর ফাইলগুলোর পরে পাল্টে থাকলে shortcut URL বদলাতে হতে পারে; পূর্ণ Admin WebView-তে Sidebar থাকবে।
- Existing Admin Login/session এবং Permissions Laravel-এর নিয়ন্ত্রণে। Native Quicklink Home-এ কোনো গোপন ডেটা নেই; Admin URL খুললেই লগইন প্রয়োজন হবে।
- Firebase Push Notification, Native API data, biometric auth এবং App auto-update **v0.1-এ নেই**। পরবর্তী ধাপে যাচাইকৃত Laravel API এবং FCM যুক্ত করা যাবে।
- APK আপডেট ছাড়াই WebView-তে ওয়েবসাইটের নতুন Blade/UI পরিবর্তন দেখা যাবে। Flutter-এর নিজের Native UI পরিবর্তন হলে APK পুনর্নির্মাণ লাগতে পারে।

## Windows PowerShell-এ Android APK Build

1. Windows-এ **Flutter Stable SDK (Dart 3.11+), Android Studio / Android SDK, Android emulator বা USB-তে Android phone** সেটআপ করুন। Java/Android licenses configure করুন।
2. ZIP Extract করে Folder খুলুন, সেই Folder-এ PowerShell চালান।
3. নিচের কমান্ডগুলো **একটি একটি করে** দিন:

```powershell
flutter doctor
flutter create --project-name soukhin_admin --platforms=android --org com.soukhinjewellery .
python tools/prepare_android.py
flutter pub get
flutter analyze
flutter test
flutter run
```

`python` কমান্ড Windows-এ না থাকলে Python 3 install করে `py tools/prepare_android.py` ব্যবহার করুন। `flutter create` Flutter-এর প্রয়োজনীয় Android scaffolding তৈরি করবে। `prepare_android.py` শুধু এই লোকাল Android Folder-এ `INTERNET` permission, `minSdk 24` এবং App Name বসায়।

সফলভাবে Android Phone-এ যাচাই করার পর:

```powershell
flutter build apk --release
```

APK তৈরি হওয়ার প্রত্যাশিত পাথ: `build\app\outputs\flutter-apk\app-release.apk`। APK অন্যকে বিতরণের আগে **নিজস্ব production keystore-এ signing** সেটআপ করবেন; Flutter-এর default debug signing production distribution-এর জন্য যথেষ্ট নয়।

## যেভাবে পরীক্ষা করবেন (সাইটে Sensitive Change না করে)

1. Mode Settings → WebView নির্বাচন → Set as Default → বন্ধ করে আবার খুলুন।
2. Admin Login → Dashboard → Orders → Product Management → POS → Landing Builder → Pixel Settings. সব Existing Feature খুলতে পারছে কিনা দেখুন।
3. Mode Settings → Native নির্বাচন → Default করুন → শর্টকাট থেকে আগের Live Page খুলে দেখুন।
4. এক ফোনের Mode Change অন্য ফোনে প্রভাব ফেলবে না।
5. Critical features: Order Creation, Status Update, Invoice/Print, Product Image Upload, POS, courier, WebView Back, PDFs, Payment, WhatsApp/Call, Mobile CSS and Dynamic Landing Editor পরীক্ষা করুন। **পরীক্ষার সময় কোনো Real Purchase Event Fire করবেন না**। Event Fire করার আগে production duplication guard server-side যাচাই করুন।
6. Mode Switch-এর পর Login Session আছে কিনা, Logout সঠিকভাবে কাজ করছে কিনা নিশ্চিত করুন।

## Existing Laravel Route-এর উৎস

27 Oct 2026-এর পাওয়া `web(20261027-045248).php` এবং আগের Responsive Mobile Admin Patch-এর `master.blade.php` থেকে যাচাই করে path নির্বাচন করা হয়েছে: `/admin/dashboard`, `/admin/order/all`, `/admin/products/manage`, `/admin/pos`, `/admin/pixels/manage`, `/admin/incomplete-checkouts`, `/admin/landing-visual-pages`, `/admin/event-fire/quick-settings` ইত্যাদি। Source files এই ZIP-এ দেওয়া হয়নি; পুরনো কোড অকারণে পুনরায় upload/deploy করা লাগবে না।

## প্রস্তাবিত পরবর্তী ধাপ (API / v0.2)

- Laravel Additive API: Sanctum or an existing compatible Token system, CSRF/session separation, Roles/Policies, API rate limit, read-only dashboard/order endpoints প্রথমে।
- Native Order/Products/Reports UI REST API-এর সঙ্গে সংযোগ। Existing models, scopes, permissions এবং service layer পুনর্ব্যবহার; business logic duplication নয়।
- Meta Purchase-এর জন্য **existing authenticated server-side admin action** ছাড়া অন্য কোনো auto trigger নয়; একই order-pixel-এর Idempotency/receipt প্রযোজ্য।
- FCM Device Token Registration ও new-order notifications: Admin অনুমতি ও সঠিক Backend Events যাচাই করে আলাদা phase-এ।

## সতর্কতা

**Live server-এর .env, SQL/DB credentials, Facebook/Meta access token, key, session cookie, SSH private key কখনো ZIP বা Source Code-এ দেবেন না।** Production Route/DB পরিবর্তনের আগে staging-এ test ও backup নিতে হবে।
